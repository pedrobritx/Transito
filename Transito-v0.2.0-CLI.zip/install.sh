#!/bin/bash

echo "Installing Transito CLI..."
echo ""

# Check if Homebrew is installed
if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew not found. Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Install dependencies
echo "Installing dependencies..."
brew install python ffmpeg

# Install CLI tool
echo "Installing Transito CLI..."
sudo cp transito /usr/local/bin/
sudo chmod +x /usr/local/bin/transito

echo ""
echo "✅ Installation complete!"
echo "Run 'transito --help' to get started"
